^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur3_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.6 (2016-04-01)
------------------
* add missing dependency for moveit_simple_controller_manager
* apply default RRTConnect to ur3
* add moveit_config for ur3
* Contributors: ipa-fxm
