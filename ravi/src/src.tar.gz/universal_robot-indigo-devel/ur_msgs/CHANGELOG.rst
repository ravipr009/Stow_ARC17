^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.6 (2016-04-01)
------------------
* Moved SetIO FUN constants from driver.py to relevant srv file for easier interaction from other files
* catkin_lint
* Contributors: Thomas Timm Andersen, ipa-fxm
